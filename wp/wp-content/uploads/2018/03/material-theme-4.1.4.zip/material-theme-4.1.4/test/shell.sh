#!/bin/sh
echo "$RANDOM"  # Unsupported in sh. Produces warning.
