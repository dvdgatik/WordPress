#### Material Theme for Sublime Text 3

## Version 4.1.4

📣 **BUG FIXES**:
* Fix some tasks not converting all schemes to .yml files ([364c912](https://github.com/equinusocio/material-theme/commit/364c912))
* Minor fixes in scheme file and convert plaintasks file to .yml ([129d114](https://github.com/equinusocio/material-theme/commit/129d114))
* Remove unnecessary .yml files in schemes folder ([2b371af](https://github.com/equinusocio/material-theme/commit/2b371af))
* Remove unnecessary json file in schemes folder ([7374d56](https://github.com/equinusocio/material-theme/commit/7374d56))

** Check the official changelog (https://github.com/equinusocio/material-theme/blob/master/CHANGELOG.md) **
