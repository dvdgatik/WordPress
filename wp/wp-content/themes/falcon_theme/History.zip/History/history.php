<?php 
/* Cabecera
Plugin Name: C7 History Developer
Plugin URI: http://localhost/WordPress/wp
Description: Have a history of what you are building in the project.
Version: 1.0
Author: David Gatica
Autor URI: http://davidgatica.esy.es
*/
 ?>

 